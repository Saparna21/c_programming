#include<stdio.h>
int main()
{
    int a ;
    scanf("%d",&a);
    if(a%3==0)
    printf("divisible bt 3");
    else
    printf("not divisible by 3 and remainder is%d",a%3);
}